public interface User {
    public String getName();
    public String getPassword();
    public String getType();
}
